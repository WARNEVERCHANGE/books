from math import sqrt

start, end = 135790, 163228

def allDivs( x ):
  q = round(sqrt(x))
  if q*q == x:
    divs = [q]
    q -= 1
  else:
    divs = []
  for d in range(1, q+1):
    if x % d == 0:
      divs = divs + [d, x//d]
  return sorted(divs)

for x in range( start, end+1 ):
  divs = allDivs(x)[1:-1]
  s = sum(divs)
  if s > 460000:
    print( len(divs), s )