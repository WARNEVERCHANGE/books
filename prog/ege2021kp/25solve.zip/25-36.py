from math import sqrt

start, end = 194441, 196500

def allDivs( x ):
  q = round(sqrt(x))
  if q*q == x:
    divs = [q]
    q -= 1
  else:
    divs = []
    q = int(sqrt(x))
  for d in range(1, q+1):
    if x % d == 0:
      divs = divs + [d, x//d]
  return sorted(divs)

qStart = int(sqrt(start))
qEnd = int(sqrt(end)) + 1

i = 0
for q in range( qStart, qEnd+1 ):
  x = q*q
  if start <= x <= end:
    divs = allDivs(x)
    i += 1
    print( i, x, len(divs), q )



