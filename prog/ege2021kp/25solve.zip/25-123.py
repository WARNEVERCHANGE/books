from math import sqrt

start, end = 416782, 498324

def isPrime(x):
  for i in range(2,round(sqrt(x))+1):
    if x % i == 0:
      return False
  return True

count = 0
mi = 0
ma = 0
for i in range(start, end+1):
  q = round(sqrt(i))
  Dx = [2] + list( range(3, q+1, 2) )
  found = False
  for x in Dx:
    if i % x == 0 and isPrime(x):
      yz = i // x
      qyz = round(sqrt(yz))
      for y in range(x+1,qyz+1):
        if yz % y == 0 and isPrime(y) and (x % 10 == y % 10):
          z = yz // y
          found = True
          if z != y and z != x and isPrime(z) and (x % 10 == z % 10):
            count += 1
            if mi == 0: mi = i
            ma = i
          break
      if found: break

print( count, ma - mi )

