from math import sqrt

start, end = 1060, 18813

def isPrime(x):
  for i in range(2,round(sqrt(x))+1):
    if x % i == 0:
      return False
  return True

s = 0
for x in range( start, end+1 ):
  if isPrime(x):
    s += x

print(s)
