from math import sqrt

start, end = 394480, 394540

def allDivs( x ):
  q = round(sqrt(x))
  if q*q == x:
    divs = [q]
    q -= 1
  else:
    divs = []
    q = int(sqrt(x))
  for d in range(1, q+1):
    if x % d == 0:
      divs = divs + [d, x//d]
  return sorted(divs)

maxDivs = []
maxLen = 0
for x in range( start, end+1 ):
  divs = allDivs( x )
  if len(divs) >= maxLen:
    if len(divs) > maxLen:
      maxDivs = []
    maxDivs.append( divs )
    maxLen = len(divs)

for i, divs in enumerate(maxDivs):
  print( i+1, len(divs), divs[-1], divs[-2] )


