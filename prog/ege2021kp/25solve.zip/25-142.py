from math import sqrt

s, e = 862346, 1056242

def allDivs( x ):
  q = round(sqrt(x))
  if q*q == x:
    divs = [q]
    q -= 1
  else:
    divs = []
    q = int(sqrt(x))
  for d in range(1, q+1):
    if x % d == 0:
      divs = divs + [d, x//d]
  return sorted(divs)

def valid( divs ):
  if len(divs) < 2: return False
  for i in range(1, len(divs)):
    if divs[i] - divs[i-1] != 100:
      return False
  return True

for x in range(s, e+1):
  divs = allDivs(x)[1:-1]
  if valid(divs):
    print( x, divs[-1] )

