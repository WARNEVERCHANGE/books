from math import sqrt

start, end = 333555, 777999

def allDivs( x ):
  q = round(sqrt(x))
  if q*q == x:
    divs = [q]
    q -= 1
  else:
    divs = []
  for d in range(1, q+1):
    if x % d == 0:
      divs = divs + [d, x//d]
  return sorted(divs)

for x in range( start, end+1 ):
  divs = allDivs(x)[1:-1]
  digits2 = [ d for d in divs if 10 <= d <= 99 ]
  if len(digits2) == 35:
    print( x, digits2[0], digits2[-1] )