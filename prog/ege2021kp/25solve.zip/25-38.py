from math import sqrt

start, end = 268220, 270335

def allDivs( x ):
  q = round(sqrt(x))
  if q*q == x:
    divs = [q]
    q -= 1
  else:
    divs = []
    q = int(sqrt(x))
  for d in range(1, q+1):
    if x % d == 0:
      divs = divs + [d, x//d]
  return sorted(divs)

qStart = int(sqrt(start))
qEnd = int(sqrt(end)) + 1

i = 0
maxSum = 0
maxDivs = []
for x in range( start, end+1 ):
  divs = allDivs( x )
  if len(divs) <= 4 and sum(divs) > maxSum:
    maxDivs = sorted( divs, reverse = True )
    maxSum = sum(divs)

print( maxSum, len(maxDivs), *maxDivs )

