from math import sqrt

start, end = 228224, 531135

def allDivs( x ):
  q = round(sqrt(x))
  if q*q == x:
    divs = [q]
    q -= 1
  else:
    divs = []
  for d in range(1, q+1):
    if x % d == 0:
      divs = divs + [d, x//d]
  return sorted(divs)

for x in range( start, end+1 ):
  divs = allDivs(x)[1:-1]
  cubes = [d for d in divs
               if round(d**(1/3))**3 == d and d % 2 == 1]
  if len(cubes) >= 4:
    print( x, len(cubes), max(cubes) )