from math import sqrt

start, end = 573213, 575340

def allDivs( x ):
  q = round(sqrt(x))
  if q*q == x:
    divs = [q]
    q -= 1
  else:
    divs = []
    q = int(sqrt(x))
  for d in range(1, q+1):
    if x % d == 0:
      divs = divs + [d, x//d]
  return sorted(divs)

qStart = int(sqrt(start))
qEnd = int(sqrt(end)) + 1

i = 0
minSum = 1e10
minDivs = []
for x in range( start, end+1 ):
  divs = allDivs( x )
  if len(divs) == 4 and sum(divs) < minSum:
    minDivs = sorted( divs, reverse = True )
    minSum = sum(divs)

print( minSum, len(minDivs), *minDivs )

