from math import sqrt

start, end = 300, 350

def allDivs( x ):
  q = round(sqrt(x))
  if q*q == x:
    divs = [q]
    q -= 1
  else:
    divs = []
    q = int(sqrt(x))
  for d in range(1, q+1):
    if x % d == 0:
      divs = divs + [d, x//d]
  return sorted(divs)[:-1]

def collect( divs, left):
  if left == 0:
    return True
  if left < 0:
    return False
  if not divs:
    return False
  return collect( divs[1:], left-divs[0]) or collect( divs[1:], left )

for x in range( start, end+1 ):
  divs = allDivs(x)
  if sum(divs) >= x:
    if collect( divs, x ):
      print( x )
