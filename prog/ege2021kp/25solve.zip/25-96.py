from math import sqrt

start, end = 81234, 134689

def allDivs( x ):
  q = round(sqrt(x))
  if q*q != x:
    return [0]
  divs = [q]
  for d in range(1, q):
    if x % d == 0:
      divs = divs + [d, x//d]
  return sorted(divs)

for x in range( start, end+1 ):
  divs = allDivs(x)
  if len(divs) == 5:
    print( divs[1], divs[3] )