from math import sqrt

start, end = 2, 263000

def allDivs( x ):
  q = round(sqrt(x))
  if q*q == x:
    divs = [q]
    q -= 1
  else:
    divs = []
    q = int(sqrt(x))
  for d in range(1, q+1):
    if x % d == 0:
      divs = divs + [d, x//d]
  return sorted(divs)

for x in range( start, end+1 ):
  sDivs = sum(allDivs( x ))
  if sum(allDivs(sDivs)) == 2*x:
    print( x )
