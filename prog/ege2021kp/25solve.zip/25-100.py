from math import sqrt

start, end = 326496, 649632

def allDivs( x ):
  q = round(sqrt(x))
  if q*q == x:
    divs = [q]
    q -= 1
  else:
    divs = []
  for d in range(1, q+1):
    if x % d == 0:
      divs = divs + [d, x//d]
  return sorted(divs)

for x in range( start, end+1 ):
  divs = allDivs(x)
  even = [d for d in divs if d % 2 == 0]
  odd = [d for d in divs if d % 2 == 1]
  if len(odd) == len(even) and len(even) >= 70:
    print( x, min( d for d in divs if d > 1000 ) )