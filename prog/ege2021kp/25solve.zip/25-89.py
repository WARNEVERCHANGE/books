from math import sqrt

start, end = 2948, 20194

def isPrime(x):
  for i in range(2,round(sqrt(x))+1):
    if x % i == 0:
      return False
  return True

for x in range( end, start-1, -1 ):
  if isPrime(x):
    print(x)
    break
