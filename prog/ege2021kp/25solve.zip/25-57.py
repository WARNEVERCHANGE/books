from math import sqrt

start, end = 5408238, 5408389

def isPrime( x ):
  q = round(sqrt(x))
  for d in range(2, q+1):
    if x % d == 0:
      return False
  return True

count = 0
for x in range( start, end+1 ):
  if isPrime( x ):
    count += 1
    print( count, x )

