from math import sqrt

start, end = 358633892, 535672891

def isPrime( x ):
  q = round(sqrt(x))
  if q*q == x: return False
  for i in range(2, q+1):
    if x % i == 0:
      return False
  return True

q4s = int(start**0.25)
q4e = int(end**0.25) + 1
for q4 in range(q4s, q4e+1):
  x = q4**4
  if start <= x <= end  and  isPrime(q4):
    print( x, [q4, q4**2, q4**3] )

