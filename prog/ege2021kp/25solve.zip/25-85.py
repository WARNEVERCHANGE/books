from math import sqrt

start, end = 3661, 33625

def isPrime(x):
  for i in range(2,round(sqrt(x))+1):
    if x % i == 0:
      return False
  return True

count = 0
qStart = int(sqrt(start))
qEnd = int(sqrt(end))+1
for q in range( qStart, qEnd ):
  x = q*q
  if start <= x <= end and isPrime(q):
    count += 1

print( count )